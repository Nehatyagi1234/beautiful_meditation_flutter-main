package com.codeforany.meditation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
